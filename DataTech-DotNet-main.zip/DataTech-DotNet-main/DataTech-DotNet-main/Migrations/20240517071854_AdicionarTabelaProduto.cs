﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace BackEndDataTech.Migrations
{
    /// <inheritdoc />
    public partial class AdicionarTabelaProduto : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
